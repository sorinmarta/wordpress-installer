$(document).ready(function(){
    $('#wordpress-installation').submit(function(evt){
        evt.preventDefault();

        var formData = $(this).serialize();
        var url = $(this).attr('action');

        $.post(url, formData, function(result){
            $('#response').html('<div class="alert alert-success" id="success-alert" role="alert">'+result+'</div>');
        });

        // var install_label = $('#instal-label').serialize();
        // var install_folder = $('#instal-folder').serialize();
        // var install_version = $('#instal-version').serialize();

        // $.ajax({
        //     url:'new_installation.php',
        //     data:{
        //         install_label: install_label,
        //         install_folder: install_folder,
        //         install_version: install_version,
        //     },
        //     type:'POST',
        //     success:function(data){
        //         $('#response').html('<div class="alert alert-success" id="success-alert" role="alert">'+data+'</div>');
        //     },
        //     error:function () {
        //         $('#response').html('<div class="alert alert-danger" id="danger-alert" role="alert">Error!</div>');
        //     }
        // });
    });
});